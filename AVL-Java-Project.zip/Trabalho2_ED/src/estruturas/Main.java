package estruturas;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArvoreAVL avl = new ArvoreAVL();
		
		Nodo aux=new Nodo();

		Scanner sc = new Scanner(System.in);
		int resp = 0;

		do {

			System.out.println("\n___________________MENU___________________\n");
			System.out.println("\nPOR FAVOR, ESCOLHA UMA OP��O: \n");
			System.out.println("1) Inserir valores na �rvore;");
			System.out.println("2) Remover valores da �rvore;");
			System.out.println("3) Imprimir valores da �rvore;");
			System.out.println("4) Pesquisar valores da �rvore;");
			System.out.println("5) Informar o maior valor da �rvore;");
			System.out.println("6) Informar o menor valor da �rvore;");
			System.out.println("7) Sair");

			resp = sc.nextInt();

			switch (resp) {

			case 1:

				System.out.println("Informe um valor para a �rvore: ");
				
				int val1 = sc.nextInt();

				avl.insereValor(avl.getRaiz(),val1);
				avl.verificaBalance(avl.getRaiz());
				avl.calculaAlt(avl.getRaiz());

				
				System.out.println("\nValor inserido com sucesso :) \n");
				
				break;

			case 2:
				
				System.out.println("Informe um valor para ser removido: ");
				int val2=sc.nextInt();
				
				avl.removeValor(avl.getRaiz(), val2);
				avl.verificaBalance(avl.getRaiz());
				avl.calculaAlt(avl.getRaiz());

				break;

			case 3:
				
				avl.imprimeValores(avl.getRaiz());

				break;

			case 4:

				System.out.println("Informe um valor para ser pesquisado: ");
				int val4=sc.nextInt();
				
				avl.pesquisaValores(avl.getRaiz(),val4);
				avl.verificaBalance(avl.getRaiz());
				avl.calculaAlt(avl.getRaiz());
				
				break;

			case 5:
				
				int val5=avl.maiorValor(avl.getRaiz());
				
				System.out.println("O maior valor da �rvore �: "+val5);
				
				break;
				
			case 6:
				
				int val6=avl.menorValor(avl.getRaiz());
				
				System.out.println("O menor valor da �rvore �: "+val6);
				
				break;

			}

		} while (resp != 7);

		System.out.println("\nFim do programa!");
		sc.close();
	}

}