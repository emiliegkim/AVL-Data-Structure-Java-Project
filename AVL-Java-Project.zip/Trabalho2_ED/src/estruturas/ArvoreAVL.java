package estruturas;

public class ArvoreAVL {

	private Nodo raiz;

	public ArvoreAVL() {

	}

	public Nodo getRaiz() {
		return raiz;
	}

	public void setRaiz(Nodo raiz) {
		this.raiz = raiz;
	}

	// ROTA��ES

	public void rotaDir(Nodo aux) {

		aux.setEsq(aux.getFilho().getDir());
		aux.getFilho().getDir().setPai(aux);
		aux.getFilho().setDir(aux);
		aux.setPai(aux.getFilho());
		aux.getPai().setDir(aux.getFilho());
		aux.getFilho().setPai(aux.getPai());
	}

	public void rotaEsq(Nodo aux) {

		aux.setDir(aux.getFilho().getEsq());
		aux.getFilho().getEsq().setPai(aux);
		aux.getFilho().setEsq(aux);
		aux.setPai(aux.getFilho());
		aux.getPai().setEsq(aux.getFilho());
		aux.getFilho().setPai(aux.getPai());

	}

	public void rotaDirEsq(Nodo aux) {

		Nodo pai = aux.getPai();
		Nodo filho = aux.getEsq();

		aux.setEsq(filho.getDir());

		if (filho.getDir() != null)
			filho.getDir().setPai(aux);

		filho.setDir(aux);
		aux.setPai(filho);

		if (aux.getValor() < pai.getValor())
			pai.setEsq(filho);
		else {
			pai.setDir(filho);
			filho.setPai(pai);
		}

		aux.setDir(filho.getEsq());

		if (filho.getEsq() != null)
			filho.getEsq().setPai(aux);

		filho.setEsq(aux);
		aux.setPai(filho);

		if (aux.getValor() < pai.getValor())
			pai.setEsq(filho);
		else {
			pai.setDir(filho);
			filho.setPai(pai);
		}

	}

	public void rotaEsqDir(Nodo aux) {

		Nodo pai = aux.getPai();
		Nodo filho = aux.getEsq();

		aux.setDir(filho.getEsq());

		if (filho.getEsq() != null)
			filho.getEsq().setPai(aux);

		filho.setEsq(aux);
		aux.setPai(filho);

		if (aux.getValor() < pai.getValor())
			pai.setEsq(filho);
		else {
			pai.setDir(filho);
			filho.setPai(pai);
		}

		aux.setEsq(filho.getDir());

		if (filho.getDir() != null)
			filho.getDir().setPai(aux);

		filho.setDir(aux);
		aux.setPai(filho);

		if (aux.getValor() < pai.getValor())
			pai.setEsq(filho);
		else {
			pai.setDir(filho);
			filho.setPai(pai);
		}

	}

	// BALANCEAMENTO

	public void verificaBalance(Nodo aux) {
	    if (aux != null && aux.getFilho() != null) { // Verificar se aux e aux.getFilho() não são nulos
	        if (aux.getBalance() == -2) {
	            if (aux.getEsq() != null && aux.getEsq().getBalance() < 0)
	                rotaDir(aux);
	            else
	                rotaEsqDir(aux);
	        } else if (aux.getBalance() == 2) {
	            if (aux.getDir() != null && aux.getDir().getBalance() > 0)
	                rotaEsq(aux);
	            else
	                rotaDirEsq(aux);
	        }
	    } else {
	        System.out.println(" ");
	    }
	}

	// ALTURA

	public int calculaAlt(Nodo aux) {
		if (aux == null)
			return 0;
		else {
			int esq = calculaAlt(aux.getEsq());
			int dir = calculaAlt(aux.getDir());
			aux.setBalance(dir - esq);
			if (esq > dir) {
				aux.setAlt(esq);
				return esq + 1;
			} else {
				aux.setAlt(dir);
				return dir + 1;
			}

		}

	}

	// INSER��O

	public void insereValor(Nodo aux, int valor) {

		if (aux != null) {
			Nodo novo = new Nodo(valor);
			if (valor < aux.getValor()) {

				if (aux.getEsq() != null)
					insereValor(aux.getEsq(), valor);
				else {
					System.out.println("Inserindo " + valor + " a esquerda de " + aux.getValor());
					aux.setEsq(novo);
				}
			} else if (valor > aux.getValor()) {
				if (aux.getDir() != null) {
					insereValor(aux.getDir(), valor);
				} else {
					System.out.println("Inserindo " + valor + " a direita de " + aux.getValor());
					aux.setDir(novo);
				}
			}
			novo.setPai(aux);
			calculaAlt(aux);
			System.out.println("*********** Verifica balanceamento de " + aux.getValor());
			verificaBalance(aux);
		} else {
			System.out.println("Inserindo " + valor + " na raiz");
			setRaiz(new Nodo(valor));
		}

	}

	// REMO��O

	public void removeFolha(Nodo aux, int valor) {

		if (aux.getPai() != null) {
			if (aux.getValor() < aux.getPai().getValor())
				aux.getPai().setEsq(null);
			else
				aux.getPai().setDir(null);
		} else
			setRaiz(null);
		aux = null;
		System.out.println("Nodo " + valor + " removido com sucesso!");

	}

	public void removeNodoUmaSubarvDir(Nodo aux, int valor) {

		if (aux.getPai() != null) {
			if (aux.getValor() < aux.getPai().getValor())
				aux.getPai().setEsq(aux.getDir());
			else
				aux.getPai().setDir(aux.getDir());
		} else
			setRaiz(aux.getDir());
		aux = null;
		System.out.println("Nodo " + valor + " removido com sucesso!");
	}

	public void removeNodoUmaSubarvEsq(Nodo aux, int valor) {

		if (aux.getPai() != null) {
			if (aux.getValor() < aux.getPai().getValor())
				aux.getPai().setEsq(aux.getEsq());
			else
				aux.getPai().setDir(aux.getEsq());
		} else
			setRaiz(aux.getEsq());
		aux = null;
		System.out.println("Nodo " + valor + " removido com sucesso!");
	}

	public void removeNodoDuasSubarvs(Nodo aux, int valor) {

		// teste se aux tem dois filhos
		Nodo aux2 = aux.getEsq();
		Nodo paiaux2 = aux.getEsq();
		while (aux2.getDir() != null) {
			paiaux2 = aux2;
			aux2 = aux2.getDir();
		}
		paiaux2.setDir(aux2.getEsq());
		if (aux.getPai() != null) {
			if (aux.getValor() < aux.getPai().getValor())
				aux.getPai().setEsq(aux2);
			else
				aux.getPai().setDir(aux2);
		} else
			setRaiz(aux2);
		aux2.setDir(aux.getDir());
		if (aux2 != aux.getEsq())
			aux2.setEsq(aux.getEsq());
		aux = null;
		System.out.println("Nodo " + valor + " removido com sucesso!");

	}

	public void removeValor(Nodo aux, int valor) {

		if (aux != null) {
			Nodo pai = null;
			if (aux.getPai() != null)
				pai = aux.getPai();
			if (valor == aux.getValor()) {
				// teste se � aux folha
				if (aux.getEsq() == null && aux.getDir() == null)
					removeFolha(aux, valor);
				else {
					// teste se aux s� tem filho � direita
					if (aux.getEsq() == null && aux.getDir() != null)
						removeNodoUmaSubarvDir(aux, valor);
					else {
						// teste se aux s� tem um filho � esquerda
						if (aux.getEsq() != null && aux.getDir() == null)
							removeNodoUmaSubarvEsq(aux, valor);
						else
							// teste se aux tem dois filhos
							removeNodoDuasSubarvs(aux, valor);
					}
				}

			} else {
				if (valor < aux.getValor())
					removeValor(aux.getEsq(), valor);
				else if (valor > aux.getValor())
					removeValor(aux.getDir(), valor);
			}
			// ap�s remover aux -> atualizar as alturas e os FBs dos demais nodos anteriores
			// a este
			if (pai != null) {
				pai.setAlt(calculaAlt(pai) - 1);
				verificaBalance(pai);
			}
		} else
			System.out.println("Valor n�o encontrado!");

	}

	// IMPRESS�O

	public void imprimeValores(Nodo aux) {

		if (aux != null) {
			System.out.println(aux.getValor());
			imprimeValores(aux.getEsq());
			imprimeValores(aux.getDir());
		}
	}

	// PESQUISA

	public Nodo pesquisaValores(Nodo aux, int valor) {
		
	    while (aux != null && aux.getValor() != valor) {
	        if (valor < aux.getValor()) {
	            aux = aux.getEsq();
	        } else {
	            aux = aux.getDir();
	        }
	    }
	    
	    if (aux == null) {
	        System.out.println("Valor " + valor + " não encontrado!");
	    } else {
	        System.out.println("Valor " + aux.getValor() + " encontrado");
	        System.out.println("Altura: " + aux.getAlt());
	        System.out.println("Fator de Balanceamento: " + aux.getBalance());
	    }
	    
	    return aux;
	}

	// MAIOR VALOR

	public int maiorValor(Nodo aux) {

		if (aux == null) {
			throw new IllegalArgumentException("A �rvore est� vazia.");
		}
		Nodo atual = aux;
		while (atual.getDir() != null) {
			atual = atual.getDir();
		}

		return atual.getValor();
	}

	// MENOR VALOR

	public int menorValor(Nodo aux) {

		if (aux == null) {
			throw new IllegalArgumentException("A �rvore est� vazia.");
		}

		Nodo atual = aux;
		while (atual.getEsq() != null) {
			atual = atual.getEsq();
		}

		return atual.getValor();
	}

}