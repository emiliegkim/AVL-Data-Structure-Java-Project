package estruturas;

public class Nodo {
	
	private int valor, balance, alt;
	private Nodo esq, dir, pai;
	private Nodo filho;

	public Nodo() {
		// TODO Auto-generated constructor stub
		setValor(0);
		setAlt(0);
		setBalance(0);
		setEsq(null);
		setDir(null);
		setPai(null);
		setFilho(null);
	}
	
	public Nodo(int valor) {
		setValor(valor);
		setAlt(0);
		setBalance(0);
		setEsq(null);
		setDir(null);
		setPai(null);
		setFilho(null);
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public int getAlt() {
		return alt;
	}

	public void setAlt(int alt) {
		this.alt = alt;
	}

	public Nodo getEsq() {
		return esq;
	}

	public void setEsq(Nodo esq) {
		this.esq = esq;
	}

	public Nodo getDir() {
		return dir;
	}

	public void setDir(Nodo dir) {
		this.dir = dir;
	}

	public Nodo getPai() {
		return pai;
	}

	public void setPai(Nodo pai) {
		this.pai = pai;
	}

	public Nodo getFilho() {
		return filho;
	}

	public void setFilho(Nodo filho) {
		this.filho = filho;
	}

	
}